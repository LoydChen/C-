 ///
 /// @file    bool.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2016-04-16 11:51:07
 ///
 
#include <iostream>
using std::cout;
using std::endl;

int main(void)
{
	bool flag1 = 10;
	bool flag2 = 0;
	bool flag3 = true;
	bool flag4 = false;
	cout << "flag1 = " << flag1 << endl;
	cout << "flag2 = " << flag2 << endl;

	cout << "flag3 = " << flag3 << endl;
	cout << "flag4 = " << flag4 << endl;
	cout << "sizeof(bool) = " << sizeof(bool) << endl;
}
